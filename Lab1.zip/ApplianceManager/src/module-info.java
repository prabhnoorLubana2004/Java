/**
 * 
 */
/**
 * 
 */
module ApplianceManager {
}